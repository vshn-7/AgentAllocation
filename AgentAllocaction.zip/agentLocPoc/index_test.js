const labels = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
let labelIndex = 0;
const AgentMarkerArr = [];

async function initMap() {
  const { Map } = await google.maps.importLibrary("maps");
  const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");

  const chennai = { lat: 13.067439, lng: 80.237617 };
  const map = new Map(document.getElementById("map"), {
    zoom: 12,
    center: chennai,	
    mapId: "4504f8b37365c3d0",
  });

  const geocoder = new google.maps.Geocoder();
  getAgentData(geocoder, map);
  setInterval(function() {
    console.log("erasing markers!!!!");
    getAgentData(geocoder, map);
  }, 60000);
}

function getAgentData(geocoder, map) {
  // Static data for testing
  const res = {
    agentDetails: [
      {
        currLoc: "13.067439,80.237617",
        empCode: "EMP001",
        name: "Agent 1",
        line1: "Line 1 Info",
        line2: "Line 2 Info",
        line3: "Line 3 Info",
        colorCode: "#00FA9A",// light green
        shape: "square",
        pincode: "600001,600002",
        currPincode: "600001"
      },
      {
        currLoc: "13.035972,80.208245",
        empCode: "EMP002",
        name: "Agent 2",
        line1: "Line 1 Info",
        line2: "Line 2 Info",
        line3: "Line 3 Info",
        colorCode: "#0000CD",  // light blue
        shape: "triangle",
        pincode: "600003,600004",
        currPincode: "600003"
      },
      {
        currLoc: "13.082680,80.270718",
        empCode: "EMP003",
        name: "Agent 3",
        line1: "Line 1 Info",
        line2: "Line 2 Info",
        line3: "Line 3 Info",
        colorCode: "#ff9100",  // light yellow
        shape: "star",
        pincode: "600005,600006",
        currPincode: "600005"
      },
      {
        currLoc: "13.060422,80.249583",
        empCode: "EMP004",
        name: "Agent 4",
        line1: "Line 1 Info",
        line2: "Line 2 Info",
        line3: "Line 3 Info",
        colorCode: "#FF6347",  // light red
        shape: "circle",
        pincode: "600007,600008",
        currPincode: "600007"
      }
    ]
  };
  plotAgentMarkers(geocoder, map, res);
}

function erraseAgentMarkers() {
  let arrLen = AgentMarkerArr.length;
  for (let i = 0; i < arrLen; i++) {
    AgentMarkerArr[i].map = null;
  }
  AgentMarkerArr.length = 0;
}

function plotAgentMarkers(geocoder, map, res) {
  erraseAgentMarkers();
  const agentinfo = res.agentDetails;
  for (let i = 0; i < agentinfo.length; i++) {
    if (agentinfo[i].currLoc != null && agentinfo[i].currLoc !== "") {
      geoMapCordinates(geocoder, map, agentinfo[i]);
    }
  }
}

async function geoMapCordinates(geocoder, map, agentinfo) {
  const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");
  const input = agentinfo.currLoc;
  const latlngStr = input.split(",");
  const agentLocation = {
    lat: parseFloat(latlngStr[0]),
    lng: parseFloat(latlngStr[1]),
  };

  if (agentinfo.currLoc != null) {
    let colorCode = agentinfo.colorCode; // Use predefined color code
    let shape = agentinfo.shape; // Use predefined shape

    let text = agentinfo.empCode;
    let first2 = text.substring(0, 2);
    let last3 = text.slice(-3);
    let shortName = first2 + last3;

    const contentValue = document.createElement("div");
    contentValue.classList.add("agent");
    contentValue.classList.add(shape);
    contentValue.classList.add("collapsed");
    contentValue.innerHTML = `<div class="icon">
                <img src="${getShapeSVG(shape, colorCode)}" alt="${shape}" />
            </div>
            <div class="name">
              ${agentinfo.name} 
            </div>
            <div class="name2">
              ${shortName} |  ${agentinfo.line1} | ${agentinfo.line2} | ${agentinfo.line3}
            </div>
            <div class="line">
              ${agentinfo.line1}
            </div>
            <div class="line">
              ${agentinfo.line2}
            </div>
            <div class="line">
              ${agentinfo.line3}
            </div>`;

    let titleVal = agentinfo.empCode + " | " + agentinfo.line1 + " | " + agentinfo.line2 + " | " + agentinfo.line3;

    const marker = new AdvancedMarkerElement({
      map,
      position: agentLocation,
      content: contentValue,
      title: titleVal,
      icon: {
        url: getShapeSVG(shape, colorCode),
        scaledSize: new google.maps.Size(48, 48)
      }
    });

    marker.addListener("click", () => {
      toggleHighlight(marker);
    });
    AgentMarkerArr.push(marker);
  } else {
    window.alert("No results found");
  }
}

function getShapeSVG(shape, color) {
  const shapes = {
    circle: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><circle cx="12" cy="12" r="10" fill="${color}" /></svg>`,
    triangle: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><polygon points="12,2 2,22 22,22" fill="${color}" /></svg>`,
    square: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><rect x="4" y="4" width="16" height="16" fill="${color}" /></svg>`,
    star: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><polygon points="12,2 15,9 22,9 17,14 18,22 12,18 6,22 7,14 2,9 9,9" fill="${color}" /></svg>`
  };

  return `data:image/svg+xml;base64,${btoa(shapes[shape])}`;
}

function toggleHighlight(markerView) {
  if (markerView.content.classList.contains("collapsed")) {
    markerView.content.classList.remove("collapsed");
    markerView.zIndex = 1;
  } else {
    markerView.content.classList.add("collapsed");
    markerView.zIndex = null;
  }
}

window.initMap = initMap;
