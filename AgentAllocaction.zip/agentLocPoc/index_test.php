<?php
include ('../vghead.php');
$con = db_connect();

?>
<html>
  <head>
    <title>Marker Labels</title>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>

    <link rel="stylesheet" type="text/css" href="./style.css?v=1.14.0" />
	
    <script type="module" src="./index.js"></script>
  </head>
  <body>
	<div style="width: 55%; float:left">
    <div id="map"></div>
    <!-- 
      The `defer` attribute causes the callback to execute after the full HTML
      document has been parsed. For non-blocking uses, avoiding race conditions,
      and consistent behavior across browsers, consider loading using Promises.
      See https://developers.google.com/maps/documentation/javascript/load-maps-js-api
      for more information.
      -->
    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCzrk2bqzyT1QgJ_RXrjjqWtQE784IcMBU&callback=initMap&v=weekly"
      defer
    ></script>
	</div>
	<div style="width: 45%; float:right" id='report_data'>
	<center>
	<?php
	$emp_type = "  and agent_type in ('SO')";
	$type = "  and agent_type in ('IGL','SO','TL')";
	$tl_type=" and agent_type='TL'";	
	/* Table-1 Progress Table */
	 $query = "select count(distinct(agent_code)) as count from ul_attendance a where type='CHECKIN' AND DATE(create_time) >= DATE(NOW()) and agent_code in (select username from ul_agent_master where username=a.agent_code $emp_type);";
	$result = mysqli_query($con, $query);
	$count = 0;
	$curr_hour = date('H');
	$hour_diff = $curr_hour - 10;
	
	if ($result->num_rows > 0) {
	    while ($row = $result->fetch_assoc()) { 
		$count = $row["count"];
		//$count=10;
	    }
	    $checkInsForToday = $count * 1.5;
	    $loans_count_daily = getSingleDBVal($con,"select count(*) as target from ul_customer_state_status s where esign_status = 1 and date(create_time)>=date(now()) and cust_id in (select cust_id from ul_customer_details c where c.cust_id=s.cust_id and c.agent_code in (select username from ul_agent_master where username=c.agent_code $emp_type))");
	 
	    
	    $loans_count_live = getSingleDBVal($con, "select count(distinct(cust_id)) as target from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and username in (select username from ul_agent_master where username=s.username $type) and cust_id not in (select cust_id from ul_state_status where state='TOPUP')");
	    
	   // $tlloans_count_live = getSingleDBVal($con, "select count(distinct(cust_id)) as target from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and username in (select username from ul_agent_master where username=s.username $tl_type) and cust_id not in (select cust_id from ul_state_status where state='TOPUP')");
	    //echo "$count, $loans_count , $checkInsForToday, </br>";	

	    $daily_progress = ($loans_count_daily / $checkInsForToday) * 100;
	     
	    // Rounding off the count
	   // $rounded_count = number_format((float)$daily_progress, 2, '.', '');
	 $rounded_count = round($daily_progress);
    
	    $live_progress=50;
	    if($hour_diff <=0) { $hour_diff =1 ; } //if 0 then INF comes by dividing
	    $target_per_hour = ($count * 1.5)/9;
	    $live_progress =  ($loans_count_live)/($target_per_hour * $hour_diff) * 100;
	     if ($loans_count_live > 0) {
    		$live_progress = round($live_progress);
		    //$live_count = number_format((float)$live_progress, 2, '.', '');
			$live_count = $live_progress;
		} else {
		    $live_count = number_format((float)0);
		}
	}

        $disb = getSingleDBVal($con, "select count(*) as target from lms_loan where type='FLMBL' and status='ACTIVE' and date(disb_time) >= CURDATE() and scheme not like '%_TP%'");
  
	?>
	<div style="display: flex; justify-content: space-between;">
	    <table border="1" width="100%" height="100" id="customers">
		<tr>
		    <td><p style="font-size:70px;"><?php echo $rounded_count; ?><span style="font-size: 25px;">%</span></p></td>
		</tr> 
		<tr><td><b>Daily Progress</b></td></tr>
	    </table>

	    <table border="1" width="100%" height="100%" id="customers">
		<tr>
		    <td><p style="font-size:70px;"><?php echo $live_count; ?><span style="font-size: 25px;">%</span></p></td>
		</tr> 
		<tr><td><b>Live Progress</b></td></tr>
	    </table>
	    
	    <table border="1" width="100%" height="100%" id="customers">
	    <tr>
		<td><p style="font-size:70px;"><?php echo $loans_count_live; ?></p></td>		 
		<td> <p style="font-size:70px;"><?php echo $disb; ?></p></td>			
	    </tr>
	    <tr>
	    <td><b>No of Loans</b></td>
	    <td><b>No of Disbursed</b></td>
	    </tr>
	    </table>
	    <br>
	</div>
	<?php
	/* Table-2 */
	$date_time = date('Y-m-d'). " 10:30:00";
	$total_executive = getSingleDBVal($con, "select count(*) as target from ul_agent_master where active=1 $emp_type and sales_eligible=1 and collection_flag=0");
	$today_login = getSingleDBVal($con, "select count(*) as target from ul_agent_master where active=1 and date(attendance_date) >=date(now()) $emp_type and attendance_flag=1 and sales_eligible=1 and collection_flag=0");
	$today_activity = getSingleDBVal($con, "select count(distinct(username)) as target from ul_state_status where date(create_time)>=date(now()) and create_time<= '$date_time' and username in (select username from ul_agent_master where active=1 $emp_type)");
	$total_executive_per = "100";
	$today_login_per = ($today_login/$total_executive)*100;
	$today_login_per = number_format((float)$today_login_per, 2, '.', '');
	$today_activity_per = ($today_activity/$today_login)*100;
	$today_activity_per = number_format((float)$today_activity_per, 2, '.', '');
	?>
	<table border="1" width="75%" id="customers">
		<tr><th>Category</th><th>Total Count</th><th>%</th></tr>
		<tr><td>Executives</td><td><p style="font-size:40px;"><?php echo $total_executive; ?></td><td><?php echo $total_executive_per; ?></p></td></tr>
		<tr><td>Login</td><td><p style="font-size:40px;"><?php echo $today_login; ?></td><td><?php echo $today_login_per; ?></p></td></tr>
	<!--	<tr><td>Activity@10:30</td><td><?php echo $today_activity; ?></td><td><?php echo $today_activity_per; ?></td></tr> -->
	</table>
	<?php
	// Table-3
$unallocated= getSingleDBVal($con, "select count(*) as target from ul_task_details where status in ('INIT') and active = 1 and (current_agent is null or current_agent = '' )");
$free_agent= getSingleDBVal($con, "select count(*) as target from ul_agent_master where agent_type in ('SO') and sales_eligible = 1 and current_task=0 and active=1 and attendance_flag = 1 and date(attendance_date) >= date(now()) and collection_flag=0");

echo '<table border="1" width="75%" id="customers">';
echo '<tr><th>UnAllocated Leads</th><th>Free Agents</th></tr>';
echo "<tr>";
echo "<td>$unallocated</td>";
echo "<td>$free_agent</td>";
echo "</tr>";
echo '</table>';

		/* Table-3 
$agency_master = "select a.id AS team_id, a.team_name, a.tl_name AS team_lead, b.asm_name AS asm_name from ul_team_master a left join ul_agent_master b on a.tl_name = b.name where a.active = 1 group by b.asm_name, a.id";
$result = mysqli_query($con, $agency_master);
$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);

echo '<table border="1" width="75%" id="customers">';
echo '<tr><th>ASM Name</th><th>Team</th><th>Team Lead</th><th>SO</th><th>Lead</th><th>Loan</th><th>TL Loan</th></tr>';

$asm_lead_count = array(); // to store the count of team leads for each ASM
$asm_totals_row = array(); // to store the row totals for each ASM

$prev_asm_name = '';
$total_rows = 0;

foreach ($rows as $row) {
    $team_id = $row['team_id'];
    $team_name = $row['team_name'];
    $team_lead = $row['team_lead'];
    $asm_name = $row['asm_name'];
    $agency_code = $team_name;
    $asm_id = getSingleDBVal($con, "select asm_id as target from ul_agent_master where name='$team_lead'");
    $asm_name = getSingleDBVal($con, "select name as target from ul_agent_master where id='$asm_id'");
    $username_team = getSingleDBVal($con, "select username as target from ul_agent_master where name='$team_lead'");
    $today_exec = getSingleDBVal($con, "select count(distinct(agent_id)) as target from ul_attendance where type='CHECKIN' and date(create_time)>=date(now()) and agent_id in (select id from ul_agent_master where team_id = $team_id and agent_type in ('SO','IGL'))");
    $today_lead = getSingleDBVal($con, "select count(*) as target from ul_customer_details where date(soc_prequalify_time)=date(now()) and applicant_type = 'APP' and lead_active_status not in('CANCELLED','DUPLICATE') and date(create_time) >= date(now()) and agent_code in (select username from ul_agent_master where agency ='$agency_code' $emp_type);");
   $today_loan =   $loans_count_live = getSingleDBVal($con, "select count(distinct(cust_id)) as target from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and username in (select username from ul_agent_master where agency ='$agency_code' and username=s.username $emp_type) and cust_id not in (select cust_id from ul_state_status where state='TOPUP')");
   $tl_loan = getSingleDBVal($con, "select count(distinct(cust_id)) as target from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and username in (select username from ul_agent_master where agency ='$agency_code' and username=s.username $tl_type and username='$username_team') and cust_id not in (select cust_id from ul_state_status where state='TOPUP')");

    if (!isset($asm_lead_count[$asm_name])) {
        $asm_lead_count[$asm_name] = getSingleDBVal($con, "SELECT COUNT(DISTINCT (tl_name)) AS target FROM ul_team_master WHERE tl_name IN (SELECT name FROM ul_agent_master WHERE asm_id = '$asm_id' AND agent_type='TL' and active=1)");
    }

    echo "<tr>";

    if ($prev_asm_name !== $asm_name) {
        if ($asm_lead_count[$asm_name] > 0) {
            echo "<td rowspan='" . $asm_lead_count[$asm_name] . "'>$asm_name</td>";
            $prev_asm_name = $asm_name;
            $total_rows = 0;
        }
    }

    echo "<td>$team_name</td>";
    echo "<td>$team_lead</td><td>$today_exec</td><td>$today_lead</td><td>$today_loan</td><td>$tl_loan</td>";
    echo "</tr>";

    // Increment the total_rows for the current ASM
    $total_rows++;

    // Store totals for each ASM
    if (!isset($asm_totals_row[$asm_name])) {
        $asm_totals_row[$asm_name] = array('exec' => 0, 'lead' => 0, 'loan' => 0, 'tl_loan' => 0);
    }

    $asm_totals_row[$asm_name]['exec'] += $today_exec;
    $asm_totals_row[$asm_name]['lead'] += $today_lead;
    $asm_totals_row[$asm_name]['loan'] += $today_loan;
    $asm_totals_row[$asm_name]['tl_loan'] += $tl_loan;

    if ($total_rows == $asm_lead_count[$asm_name]) {
	echo "<tr><td colspan='3' style='font-size: 15px;'><strong>Total</strong></td><td style='font-size: 15px;'><strong>{$asm_totals_row[$asm_name]['exec']}</strong></td><td style='font-size: 15px;'><strong>{$asm_totals_row[$asm_name]['lead']}</strong></td><td style='font-size: 15px;'><strong>{$asm_totals_row[$asm_name]['loan']}</strong></td><td style='font-size: 15px;'><strong>{$asm_totals_row[$asm_name]['tl_loan']}</strong></td></tr>";
    }
}

echo '</table>';

	*/

	/* Table-4 */
	/*
	 $noofloan1 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) and c.agent_code in (select username from ul_agent_login where username=c.agent_code $emp_type) GROUP BY agent_code) temp WHERE temp.cnt=1";
    $loans1 = mysqli_query($con, $noofloan1);
    $noofloan2 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) and c.agent_code in (select username from ul_agent_login where username=c.agent_code $emp_type) GROUP BY agent_code) temp WHERE temp.cnt=2";
    $loans2 = mysqli_query($con, $noofloan2);
    $noofloan3 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) and c.agent_code in (select username from ul_agent_login where username=c.agent_code $emp_type) GROUP BY agent_code) temp WHERE temp.cnt=3";
    $loans3 = mysqli_query($con, $noofloan3);
    $noofloan4 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) and c.agent_code in (select username from ul_agent_login where username=c.agent_code $emp_type) GROUP BY agent_code) temp WHERE temp.cnt=4";
    $loans4 = mysqli_query($con, $noofloan4);
    $noofloan5 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) and c.agent_code in (select username from ul_agent_login where username=c.agent_code $emp_type) GROUP BY agent_code) temp WHERE temp.cnt=4";
    $loans5 = mysqli_query($con, $noofloan5);
    */
    //Loans Count Based on Today ESIGN
	

    $today_login = getSingleDBVal($con, "select COUNT(*) AS target from ul_agent_master where active=1 and DATE(attendance_date) >= DATE(NOW()) $emp_type and attendance_flag=1 and sales_eligible=1 and collection_flag=0");

    /*$loan1 = mysqli_fetch_assoc($loans1)['COUNT(temp.agent_code)'];
    $loan2 = mysqli_fetch_assoc($loans2)['COUNT(temp.agent_code)'];
    $loan3 = mysqli_fetch_assoc($loans3)['COUNT(temp.agent_code)'];
    $loan4 = mysqli_fetch_assoc($loans4)['COUNT(temp.agent_code)'];
    $loan5 = mysqli_fetch_assoc($loans5)['COUNT(temp.agent_code)'];
    */	
    $loan1 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and username in (select username from ul_agent_master where username=s.username  $emp_type) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT=1");
    $loan2 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and username in (select username from ul_agent_master where username=s.username  $emp_type) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT=2");
    $loan3 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and username in (select username from ul_agent_master where username=s.username  $emp_type) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT=3");
    $loan4 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and username in (select username from ul_agent_master where username=s.username  $emp_type) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT=4");
    $loan5 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and username in (select username from ul_agent_master where username=s.username  $emp_type) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT>=5");

    $total_loans = $loan1 + $loan2 + $loan3 + $loan4 + $loan5;
    $loan0 = $today_login - $total_loans;
    
        $tltoday_login = getSingleDBVal($con, "select COUNT(*) AS target from ul_agent_master where active=1 and DATE(attendance_date) >= DATE(NOW()) $tl_type and attendance_flag=1 and sales_eligible=1 and collection_flag=0");
        $tlloan1 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') and username in (select username from ul_agent_master where  username=s.username $tl_type) group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT=1");
        $tlloan2 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') and username in (select username from ul_agent_master where  username=s.username $tl_type) group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT=2");
     	$tlloan3 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') and username in (select username from ul_agent_master where username=s.username $tl_type) group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT=3");
   	$tlloan4 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') and username in (select username from ul_agent_master where  username=s.username $tl_type) group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT=4");
    	$tlloan5 = getSingleDBVal($con,"select count(tmp2.username) as target from (select tmp1.username,count(distinct(cust_id)) as userCNT from (select cust_id,username,count(*) as CNT from ul_state_status s where state='ESIGN' and date(create_time) >= date(now()) and cust_id not in (select cust_id from ul_state_status where state='TOPUP') and username in (select username from ul_agent_master where  username=s.username $tl_type) group by cust_id,username) tmp1 group by tmp1.username) tmp2 where tmp2.userCNT>=5");

    $total_tlloans = $tlloan1 + $tlloan2 + $tlloan3 + $tlloan4 + $tlloan5;
    $tl_loan0 = $tltoday_login - $total_tlloans;
?>
	<table border="1" width="55%" height="60" id="customers">
		<tr>
			<th colspan="7" style="text-align: center;">Loans</th>
		</tr>
		<tr>
			<td></td>
			<th>0</th>
			<th>1</th>
			<th>2</th>
			<th>3</th>
			<th>4</th>
			<th>5</th>
		</tr>
		<tr>
			<td>Executive</td>
			<td><?php echo $loan0?></td>
			<td><?php echo $loan1;?></td>
			<td><?php echo $loan2;?></td>
			<td><?php echo $loan3;?></td>
			<td><?php echo $loan4 ;?></td>
			<td><?php echo $loan5;?></td>
		</tr>
		<tr>
		       <td>TL</td>
		        <td><?php echo $tl_loan0?></td>
			<td><?php echo $tlloan1;?></td>
			<td><?php echo $tlloan2;?></td>
			<td><?php echo $tlloan3;?></td>
			<td><?php echo $tlloan4 ;?></td>
			<td><?php echo $tlloan5;?></td>		
		</tr>
	</table>
	
	
	<!--Table-5 -->
	<table border="1" width="55%" height="60" id="customers">
		<tr>
			<th colspan="7" style="text-align: center;">Top Performance</th>
		</tr>
		<tr>
			<td></td>
			<th>Executive</th>
			<th>Lead Count</th>
			<th>Good Lead</th>
			<th>Loans</th>
		</tr>
		<?php
		$s = 0;
		
		//$agent_top_query = "select agent_code, count(*) as cnt  from ul_customer_details c where applicant_type = 'APP' and date(create_time)>=date(now()) and cust_id in (select cust_id from ul_customer_state_status where cust_id=c.cust_id and esign_status=1) and c.agent_code in (select username from ul_agent_login where username=c.agent_code $emp_type) group by agent_code order by cnt desc limit 5;";
	/*	$agent_top_query = "select tmp.username as agent_code from (select username,count(*) as cnt from ul_state_status where state='ESIGN' and date(create_time)>=date(now()) group by username) tmp order by tmp.cnt desc limit 5";
		$agent_top_result = mysqli_query($con, $agent_top_query );
		

		$top_agents = array();	
		if ($agent_top_result->num_rows > 0) {
			while ($agent_top_row = $agent_top_result->fetch_assoc()) {
				$s = $s+ 1;
				$agent_name = $agent_top_row["agent_code"];
				array_push($top_agents, $agent_name);
				//print_r($top_agents);
				$gleads = getSingleDBVal($con, "select count(*) as target from ul_customer_details c where agent_code='$agent_name' and date(soc_prequalify_time)=date(now()) and applicant_type = 'APP' and cibil_score>650 and lead_active_status not in('CANCELLED','DUPLICATE') and date(create_time) >= DATE(NOW()) and c.agent_code in (select username from ul_agent_master where username=c.agent_code $emp_type)");
				$lead_count = getSingleDBVal($con, "select count(*) as target from ul_customer_details c where agent_code='$agent_name' and date(soc_prequalify_time)=date(now()) and applicant_type = 'APP' and lead_active_status not in('CANCELLED','DUPLICATE') and date(create_time) >= DATE(NOW()) and c.agent_code in (select username from ul_agent_master where username=c.agent_code $emp_type)");
				
				//$query = "select count(*) as target from ul_customer_state_status where  cust_id in (select cust_id from ul_customer_details where applicant_type = 'APP' and date(create_time)>=date(now()) and agent_code in (select username from ul_agent_login where username ='$agent_name' $emp_type)) and esign_status=1";
				$query = "select count(distinct(cust_id)) as target from ul_state_status where state='ESIGN' and date(create_time)>=date(now()) and username='$agent_name' and cust_id not in (select cust_id from ul_state_status where state='TOPUP')";
				$today_loans = getSingleDBVal($con, $query);
				$agent_lead= getSingleDBVal($con, "select count(*) as target from ul_customer_details c where applicant_type = 'APP' and date(create_time)>=date(now()) and agent_code='$agent_name' and c.agent_code in (select username from ul_agent_master where username=c.agent_code $emp_type)");
		 
			echo "<tr>
				<td>$s</td>
				<td>$agent_name</td>
				<td>$lead_count</td>
				<td>$gleads</td>
				<td>$today_loans</td>
			</tr>";
		   }
		}*/
		$query2 = "select * from view_agent_bottomtop order by loans desc, good_leads desc, leads desc limit 5";
		$result2 = mysqli_query($con,$query2);
		$sno = 1;
		while($row2 = mysqli_fetch_array($result2)){
			$agent_name = $row2['agent_code'];
			$leads = $row2['leads'];
			$good_leads = $row2['good_leads'];
			$loans = $row2['loans'];

			echo "<tr><td>$sno</td><td>$agent_name</td><td>$leads</td><td>$good_leads</td><td>$loans</td></tr>";
			$sno++;	
		}
		?>   
	</table>
	<!--Table-6 -->
	<table border="1" width="55%" height="60" id="customers">
		<tr>
			<th colspan="7" style="text-align: center;">Bottom Performance</th>
		</tr>
		<tr>
			<td></td>
			<th>Executive</th>
			<th>Lead Count</th>
			<th>Good Lead</th>
			<th>Loans</th>
		</tr>
	<?php
	$s = 0;
		$top_agent_list = implode("','",$top_agents);
		$top_agent_list = "('". $top_agent_list."')";

		//print_r($top_agent_list);
	
		/*$agent_bottom_query="select agent_code, count(*) as cnt from ul_customer_details c where applicant_type = 'APP' and soc_prequalify_status='REJECTED' and date(create_time)>=date(now()) and agent_code not in $top_agent_list and agent_code not in (select distinct(agent_code) from ul_customer_details where cibil_score>650 and date(create_time)>=date(now())) and c.agent_code in (select username from ul_agent_master where username=c.agent_code $emp_type) group by agent_code order by cnt asc limit 5";
		//$agent_bottom_query= "select tmp.username as agent_code from (select username,count(*) as cnt from ul_state_status where state='ESIGN' and date(create_time)>=date(now()) and username not in $top_agent_list group by username) tmp order by tmp.cnt asc limit 5";
		//echo  $agent_bottom_query;
		$agent_top_result = mysqli_query($con, $agent_bottom_query );
		
		if ($agent_top_result->num_rows > 0) {
			while ($agent_top_row = $agent_top_result->fetch_assoc()) {
				$s = $s+ 1;
				$agent_name = $agent_top_row["agent_code"];
				$gleads = getSingleDBVal($con, "select count(*) as target from ul_customer_details c where agent_code='$agent_name' and date(soc_prequalify_time)=date(now()) and applicant_type = 'APP' and cibil_score>650 and lead_active_status not in('CANCELLED','DUPLICATE','REJECTED') and date(create_time) >= DATE(NOW()) and c.agent_code in (select username from ul_agent_master where username=c.agent_code $emp_type)");

				$lead_count = getSingleDBVal($con, "select count(*) as target from ul_customer_details c where agent_code='$agent_name' and date(soc_prequalify_time)=date(now()) and applicant_type = 'APP' and lead_active_status not in('CANCELLED','DUPLICATE','REJECTED') and date(create_time) >= DATE(NOW()) and c.agent_code in (select username from ul_agent_master where username=c.agent_code $emp_type)");
				
				//$query = "select count(*) as target from ul_customer_state_status where  cust_id in (select cust_id from ul_customer_details where applicant_type = 'APP' and date(create_time)>=date(now()) and agent_code in (select username from ul_agent_login where username ='$agent_name' $emp_type)) and esign_status=1";

				$query = "select count(distinct(cust_id)) as target from ul_state_status s where  state='ESIGN' and date(create_time)>=date(now()) and username='$agent_name'";
				$today_loans = getSingleDBVal($con, $query);
				$agent_lead= getSingleDBVal($con, "select count(*) as target from ul_customer_details c where applicant_type = 'APP' and date(create_time)>=date(now()) and agent_code='$agent_name' and c.agent_code in (select username from ul_agent_master where username=c.agent_code $emp_type)");
		 
			echo "<tr>
				<td>$s</td>
				<td>$agent_name</td>
				<td>$lead_count</td>
				<td>$gleads</td>
				<td>$today_loans</td>
			</tr>";
		   }
		}*/
		$query2 = "select * from view_agent_bottomtop order by loans asc, good_leads asc, leads asc limit 5";
                $result2 = mysqli_query($con,$query2);
                $sno = 1;
                while($row2 = mysqli_fetch_array($result2)){
                        $agent_name = $row2['agent_code'];
                        $leads = $row2['leads'];
                        $good_leads = $row2['good_leads'];
                        $loans = $row2['loans'];
                        echo "<tr><td>$sno</td><td>$agent_name</td><td>$leads</td><td>$good_leads</td><td>$loans</td></tr>";
                        $sno++;
                }
                ?>							  
	</table>		
	</center>
	</div>
  </body>
</html>
<script src='../../ui/js/jquery.min.js'></script>
<script type="text/javascript">  
   setTimeout(function(){  
       location.reload();  
   },10 * 60000);   // 10 minutes

</script>
