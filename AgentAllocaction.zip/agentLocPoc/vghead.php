<?php
ini_set('session.gc_maxlifetime', 6*60*60); // 6 hours
date_default_timezone_set('Asia/Kolkata'); 
#ini_set('display_errors', 1);
#ini_set('display_startup_errors', 1);
#error_reporting(E_ALL);
/*if (!function_exists('db_connect')){
	function db_connect(){
		$serverip = "mysqlnode";
		$username = "rajesh";
		$password = "rajesh@123";
		$dbname = "FRNDLNWEB";
		$con = mysqli_connect($serverip, $username, $password, $dbname);
              if (!$con){
                     die('DB Connection Failure...!: ' . mysqli_connect_error());
              }
		return $con;
	}

}*/
if (!function_exists('db_connect')){
	function db_connect(){
		$serverip = "35.154.34.229";
		$username = "rajesh";
		$password = "rajesh@123";
		$dbname = "FRNDLNWEB";
		$con = mysqli_connect($serverip, $username, $password, $dbname);
              if (!$con){
                     die('DB Connection Failure...!: ' . mysqli_connect_error());
              }
		return $con;
	}

}
if (!function_exists('db_connect_socr')){
        function db_connect_socr(){
                $serverip = "socrates";
                $username = "socrates";
                $password = "socrates@123";
                $dbname = "socrates";
                $con = mysqli_connect($serverip, $username, $password, $dbname);
              if (!$con){
                     die('DB Connection Failure...!: ' . mysqli_connect_error());
              }
                return $con;
        }
}
if (!function_exists('closeDBConn')){
	function closeDBConn($con){
		mysqli_close($con);
	}
}

if (!function_exists('db_close')){
	function db_close($con){
		mysqli_close($con);
	}
}


function getSingleDBVal($conn, $query){
       $result = mysqli_query($conn, $query);
       if(mysqli_error($conn)){
               echo "Mysql error: $query \n";
               return -1;
       }
       if($row = mysqli_fetch_assoc($result)){
               $res = $row['target'];
               return $res;
       }
       return -1;
}

function getSingleDBValEmpty($conn, $query){
       $result = mysqli_query($conn, $query);
       if(mysqli_error($conn)){
               echo "Mysql error: $query \n";
               return "";
       }
       if($row = mysqli_fetch_assoc($result)){
               $res = $row['target'];
               return $res;
       }
       return "";
}

function getSingleDBValCount($conn, $query){
       $result = mysqli_query($conn, $query);
       if(mysqli_error($conn)){
               echo "Mysql error: $query \n";
               return 0;
       }
       if($row = mysqli_fetch_assoc($result)){
               $res = $row['target'];
               return $res;
       }
       return 0;
}


function getMilliseconds($startTime1){
$currentTime = new \DateTime("now");
    $startTime = new \DateTime($startTime1);

    $interval = $currentTime->diff($startTime);

    $totalMiliseconds = 0;
    $totalMiliseconds += $interval->m * 2630000000;
    $totalMiliseconds += $interval->d * 86400000;
    $totalMiliseconds += $interval->h * 3600000;
    $totalMiliseconds += $interval->i * 60000;
    $totalMiliseconds += $interval->s * 1000;
   
    return $totalMiliseconds;

}

function tablize_vertical_textview($conn, $query,$noofrows){

echo "<table border=\"0\" width=\"40%\" id=\"customers\">\n";
$result = mysqli_query($conn, $query);
//echo "tablize_vertical=>".$query;
//Column Headings Begin
$fields_list = mysqli_fetch_fields($result);
$no_of_fields = sizeof($fields_list);
$count = mysqli_num_rows($result);
if($count<=0){
echo "<tr>\n<td style=\"color:red;text-align:center\">NO RECORDS FOUND</td>\n</tr>\n";
echo "</table>\n";
       echo "<br><br>\n";

}else{
$row = mysqli_fetch_assoc($result);
$j=0;
for($i=0; $i<$no_of_fields; $i++){
if($j==0){
echo "<tr>\n";
}
$j = $j +1;
//Column Name : Key
$heading = $fields_list[$i]->name;
$title_found = false;

if(!$title_found){
//At least make the column name look neat
$heading = str_replace("_", " ", $heading);
$heading = ucwords($heading);
}
  echo "<td><b>$heading</b></td>\n";
 
  //Column Value
$col_name = $fields_list[$i]->name;
$value = $row[$col_name];
echo "<td>$value</td>\n";
if($j>=$noofrows){
echo "</tr>\n";
$j=0;
}
}

echo "</table>\n";
echo "<br><br>\n";
}
}

function tablize($conn, $query, $column_titles="", $id_column="", $url_prefix=""){
//	echo "<br>\n";
	echo "<table border=\"0\" width=\"75%\" id=\"customers\">\n";

	$result = mysqli_query($conn, $query);

	//Column Headings Begin
	$fields_list = mysqli_fetch_fields($result);
	$no_of_fields = sizeof($fields_list); 
	echo "<tr>\n";
	for($i=0; $i<$no_of_fields; $i++){
		$heading = $fields_list[$i]->name;
		$title_found = false;
		if($column_titles != ""){
			if(isset($column_titles[$heading])){
				$heading = $column_titles[$heading];
			}
		}
		if(!$title_found){
			//At least make the column name look neat
			$heading = str_replace("_", " ", $heading);
			$heading = ucwords($heading);
		}
 		echo "<th>$heading</th>\n";
	}
	echo "</tr>\n";
	//Column Headings End


	while($row = mysqli_fetch_assoc($result)){
		echo "<tr>\n";
		for($i=0; $i<$no_of_fields; $i++){
			echo "<td>\n";
			$col_name = $fields_list[$i]->name;
			$value = $row[$col_name];
			if($col_name == $id_column){
				echo "<a href=\"$url_prefix$value\">$value</a>";
			}else{
				echo $value;
			}
			echo "</td>\n";
		}

		echo "</tr>\n";

	}
	echo "</table>\n";
	echo "<br><br>\n";
}

function tablize_dept($conn, $query, $column_titles="", $id_column="", $url_prefix=""){
//      echo "<br>\n";
        echo "<table border=\"0\" width=\"75%\" id=\"customers\">\n";

        $result = mysqli_query($conn, $query);

        //Column Headings Begin
        $fields_list = mysqli_fetch_fields($result);
        $no_of_fields = sizeof($fields_list);
        echo "<tr>\n";
        for($i=0; $i<$no_of_fields; $i++){
                $heading = $fields_list[$i]->name;
                $title_found = false;
                if($column_titles != ""){
                        if(isset($column_titles[$heading])){
                                $heading = $column_titles[$heading];
                        }
                }
                if(!$title_found){
                        //At least make the column name look neat
                        $heading = str_replace("_", " ", $heading);
                        $heading = ucwords($heading);
                }
                echo "<th>$heading</th>\n";
 }
        echo "</tr>\n";
        //Column Headings End


        while($row = mysqli_fetch_assoc($result)){
                echo "<tr>\n";
                for($i=0; $i<$no_of_fields; $i++){
                        echo "<td>\n";
                        $col_name = $fields_list[$i]->name;
                        $value = $row[$col_name];
                        
                        if($col_name == $id_column){
                        	$query2 = "select * from lap_application where id=$value";
				$result2 = mysqli_query($conn,$query2);
				if($row2 = mysqli_fetch_array($result2)){
					$app_dept = $row2['department'];
					$state = $row2['state'];
				}
				$department = $_SESSION['department'];
				if($department == 'sales'){
					if($app_dept == 'sales'){
				                echo "<a href=\"$url_prefix$value\">$value</a>";
				        }else{
				                echo $value;
				        }
		                }else{
		                	 echo "<a href=\"$url_prefix$value\">$value</a>";
		                
				}
			}else{
				echo $value;
			}
			
				echo "</td>\n";
			}
                
		}
        echo "</tr>\n";

        echo "</table>\n";
        echo "<br><br>\n";
}

function tablize_vertical($conn, $query,$noofrows){
	
	echo "<table border=\"0\" width=\"40%\" id=\"customers\">\n";
	$result = mysqli_query($conn, $query);
	//echo "tablize_vertical=>".$query;
	//Column Headings Begin
	$fields_list = mysqli_fetch_fields($result);
	$no_of_fields = sizeof($fields_list);
	$count = mysqli_num_rows($result);
	if($count<=0){
		echo "<tr>\n<td style=\"color:red;text-align:center\">NO RECORDS FOUND</td>\n</tr>\n";
		echo "</table>\n";
	        echo "<br><br>\n";
		
	}else{	
	$row = mysqli_fetch_assoc($result);
	$j=0;
	for($i=0; $i<$no_of_fields; $i++){
		if($j==0){
			echo "<tr>\n";
		}
		$j = $j +1;
		//Column Name : Key
		$heading = $fields_list[$i]->name;
		$title_found = false;
		if($column_titles != ""){
			if(isset($column_titles[$heading])){
				$heading = $column_titles[$heading];
			}
		}
		if(!$title_found){
			//At least make the column name look neat
			$heading = str_replace("_", " ", $heading);
			$heading = ucwords($heading);
		}
 		echo "<td style=\"text-align:left\"><b>$heading</b></td>\n";
 		
 		//Column Value
		$col_name = $fields_list[$i]->name;
		$value = $row[$col_name];
		echo "<td><input type='text' value='$value' readonly></td>\n";
		if($j>=$noofrows){
			echo "</tr>\n";
			$j=0;
		}	
	}

	echo "</table>\n";
	echo "<br><br>\n";
	}
}

function tablise_vertical($conn, $query,$noofrows){
	
	echo "<table border=\"0\" width=\"75%\" id=\"customer\">\n";
	$result = mysqli_query($conn, $query);
	//echo "tablize_vertical=>".$query;
	//Column Headings Begin
	$fields_list = mysqli_fetch_fields($result);
	$no_of_fields = sizeof($fields_list);
	$count = mysqli_num_rows($result);
	if($count<=0){
		echo "<tr>\n<td style=\"color:red;text-align:center\">NO RECORDS FOUND</td>\n</tr>\n";
		echo "</table>\n";
	        echo "<br><br>\n";
		
	}else{	
	$row = mysqli_fetch_assoc($result);
	$j=0;
	for($i=0; $i<$no_of_fields; $i++){
		if($j==0){
			echo "<tr>\n";
		}
		$j = $j +1;
		//Column Name : Key
		$heading = $fields_list[$i]->name;
		$title_found = false;
		if($column_titles != ""){
			if(isset($column_titles[$heading])){
				$heading = $column_titles[$heading];
			}
		}
		if(!$title_found){
			//At least make the column name look neat
			$heading = str_replace("_", " ", $heading);
			$heading = ucwords($heading);
		}
 		echo "<td style=\"text-align:left\"><b>$heading</b></td>\n";
 		
 		//Column Value
		$col_name = $fields_list[$i]->name;
		$value = $row[$col_name];
		echo "<td><input type='text' value='$value' readonly></td>\n";
		if($j>=$noofrows){
			echo "</tr>\n";
			$j=0;
		}	
	}

	echo "</table>\n";
	echo "<br><br>\n";
	}
	
	
	
	
	
	function tablize_vertical($conn, $query,$noofrows){
	
	echo "<table border=\"0\" width=\"75%\" id=\"customers\">\n";
	$result = mysqli_query($conn, $query);
	//echo "tablize_vertical=>".$query;
	//Column Headings Begin
	$fields_list = mysqli_fetch_fields($result);
	$no_of_fields = sizeof($fields_list);
	$count = mysqli_num_rows($result);
	if($count<=0){
		echo "<tr>\n<td style=\"color:red;text-align:center\">NO RECORDS FOUND</td>\n</tr>\n";
		echo "</table>\n";
	        echo "<br><br>\n";
		
	}else{	
	$row = mysqli_fetch_assoc($result);
	$j=0;
	for($i=0; $i<$no_of_fields; $i++){
		if($j==0){
			echo "<tr>\n";
		}
		$j = $j +1;
		//Column Name : Key
		$heading = $fields_list[$i]->name;
		$title_found = false;
		if($column_titles != ""){
			if(isset($column_titles[$heading])){
				$heading = $column_titles[$heading];
			}
		}
		if(!$title_found){
			//At least make the column name look neat
			$heading = str_replace("_", " ", $heading);
			$heading = ucwords($heading);
		}
 		echo "<td style=\"text-align:left\"><b>$heading</b></td>\n";
 		
 		//Column Value
		$col_name = $fields_list[$i]->name;
		$value = $row[$col_name];
		echo "<td><input type='text' value='$value' readonly></td>\n";
		if($j>=$noofrows){
			echo "</tr>\n";
			$j=0;
		}	
	}

	echo "</table>\n";
	echo "<br><br>\n";
	}
}
	function html_open($title, $search_id = -1, $menu_on = true, $submenu_on = true){
	echo "<html>\n";
	echo "<head>\n";
$style = <<<STYLE
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 80%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color:#F0FFFF;}

#customers tr:nth-child(odd){background-color:#FFFFF7;}

#customers tr:hover {background-color:#f27719;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #800080;
  color: white;
}
/* Style the buttons that are used to open and close the accordion panel */
.accordion {
  font-family: Arial, Helvetica, sans-serif;
  font-weight: bold;
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #66b3ff;
  color: white;
  cursor: pointer;
  transition: 0.4s;
}
.accordion:after {
  content: ' \+'; /* Unicode character for "plus" sign (+) */
  color: white;
  float: right;
  padding-right: 20px;
}

.active:after {
  content: "\-"; /* Unicode character for "minus" sign (-) */
  padding-right: 20px;
}

/* Add a background color to the button if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */
.accordion:hover {
  background-color: #f27719;
}

/* Style the accordion panel. Note: hidden by default */
.panel {
  display: none;
  //max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #fefefe; /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 40px;
}
/* The Modal VGP (background) */
.modalvgp {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: scroll; /* Enable scroll if needed */
  background-color: #fefefe; /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 40px;
}
/* Modal Content/Box */
.modal_content {
  border-radius:10px;
  background-color: white;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}
/* The Close1 Button */
.close1{
  color: red;
  margin-right:15px;
  float: right;
  font-size: 35px;
  font-weight: bold;
}

.close1:hover,
.close1:focus {
  color: #f27719;
  text-decoration: none;
  cursor: pointer;
}
/* The Close2 Button */
.close2{
  color: red;
  margin-right:15px;
  float: right;
  font-size: 35px;
  font-weight: bold;
}

.close2:hover,
.close2:focus {
  color: #f27719;
  text-decoration: none;
  cursor: pointer;
}
/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}


body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #0080ff;
  border-bottom-style: solid;
  border-width: 1px;
  border-color:#F0FFFF;
}
.autocalc{
background-color: #800080;

}
.topnav button {
  float: left;
  color: #F0FFFF;
  text-align: center;
  padding: 5px 5px;
  text-decoration: none;
  background-color: #0080ff;
  font-size: 17px;
}

.topnav b {
  float: left;
  color: #f2f2f2;
  text-align: center;
  text-weight: bold;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #f27719;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
</style>
STYLE;

//TODO: Move to individual files
$department = $_SESSION['department'];
if($department == 'credit' || $department == 'ops') $submenu_on = true;
//TODO:End

	echo $style . "\n";
	echo "<title>$title</title>\n";
	echo "</head>\n";
	echo "<body>\n";
	if($menu_on){
		echo get_menu();
		if($submenu_on){
			echo get_sub_menu();
		}
	}
	echo "<center>\n";
	echo "<h2>$title &nbsp; ";
	if($search_id > 0){
		echo "<a href=\"search.php?sid=$search_id\"><input type=\"button\" name=\"Search\" value=\"Search\"></a>\n";
	}
	echo "</h2>\n";
	echo "\n\n";
}

function html_close(){
	echo "</body>\n</html>\n";
}

function form_open(){
	echo "<form name=\"form\" id=\"form1\" onsubmit=\"return validateForm()\" method=\"post\" action=\"" . $_SERVER['PHP_SELF'] . "\" enctype=\"multipart/form-data\" >\n";
}

function form_close($submit_options){
	echo "<center>\n";
	echo "<br/>\n";
	for($i=0; $i<sizeof($submit_options); $i++){
		$submit_value = $submit_options[$i];
		echo "<input type=\"submit\" name=\"submit_action\" onclick=\"return checkAmt()\" class =\"formSubmit\" id =\"btnsubmit\" value=\"$submit_value\">\n";
	}
	echo "</center>\n";
	echo "</form>\n";
}

function table_open($title){
	echo "<table border=\"0\" width=\"75%\" id=\"customers\">\n";
	echo "<tr>\n";
	echo "<th colspan=5> $title </th>\n";
	echo "</tr>\n";
	$GLOBALS['left_col'] = true;
	$GLOBALS['odd_row'] = true;
}

function table_close(){
	if(!$GLOBALS['left_col']){
		echo "<td> </td> \n";
		echo "<td> </td> \n";
		echo "</tr>\n";
	}
	echo "</table>\n";
	echo "<br/>\n";
}


}
