<?php
include ('vghead.php');
$con = db_connect();

?>
<html>
  <head>
    <title>Marker Labels</title>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>

    <link rel="stylesheet" type="text/css" href="./style.css?v=1.14.0" />
	
    <script type="module" src="./index.js"></script>
  </head>
  <body>
	<div style="width: 70%; float:left">
    <div id="map"></div>
    <!-- 
      The `defer` attribute causes the callback to execute after the full HTML
      document has been parsed. For non-blocking uses, avoiding race conditions,
      and consistent behavior across browsers, consider loading using Promises.
      See https://developers.google.com/maps/documentation/javascript/load-maps-js-api
      for more information.
      -->
    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCzrk2bqzyT1QgJ_RXrjjqWtQE784IcMBU&callback=initMap&v=weekly"
      defer
    ></script>
	</div>
	<div style="width: 30%; float:right">
	<center>
	<br><br>
	<?php
	/* Table-1 Progress Table */
	$query = "SELECT COUNT( distinct(agent_code)) as count FROM ul_attendance WHERE type='CHECKIN' AND DATE(create_time) >= DATE(NOW())";
	$result = mysqli_query($con, $query);
	$count = 0;
	if ($result->num_rows > 0) {
	    while ($row = $result->fetch_assoc()) {
		$count = $row["count"];
		//$count=10;
	    }
	    $checkInsForToday = $count * 1.5;
	    $nooflead_query = "SELECT COUNT(create_time) as count FROM ul_customer_details WHERE DATE(create_time) >= DATE(NOW())";
	    $lead_result = mysqli_query($con, $nooflead_query);
	    $lead_count = 0;
	    if ($lead_result->num_rows > 0) {
		while ($lead_row = $lead_result->fetch_assoc()) {
		    $lead_count = $lead_row["count"];
		}
	    }
	    $daily_progress = $lead_count / $checkInsForToday * 100;
	    // Rounding off the count
	    $rounded_count = number_format((float)$daily_progress, 2, '.', '');
	    $live_progress=50;
	    $live_count = number_format((float)$live_progress, 2, '.', '');
	   
	}
	?>
	<div style="display: flex; justify-content: space-between;">
		<table border="1" width="55%" height="60" id="customers">
			<tr>
		        <td><?php echo $rounded_count . "%"; ?> <br><p><b>Daily Progress </b></p></td>

			</tr>
		   
		</table>
		<table border="1" width="55%" height="60" id="customers">
			<tr>
				<td><?php echo $live_count . "%"; ?><br><p><b>Live Progress </b></p></td>
			</tr>
		</table>
		<br>
	</div>
	<?php
	/* Table-2 */
	$total_executive = getSingleDBVal($con, "select count(*) as target from ul_agent_login where active=1");
	$today_login = getSingleDBVal($con, "select count(*) as target from ul_agent_login where active=1 and date(attendance_date) >=date(now());");
	$today_activity = getSingleDBVal($con, "select count(distinct(username)) as target from ul_state_status where date(create_time)>=date(now()) and hour(create_time)<=10 and username in (select username from ul_agent_login)");

	$total_executive_per = "100";
	$today_login_per = round(($today_login/$total_executive)*100);
	$today_login_per = number_format((float)$today_login_per, 2, '.', '');
	$today_activity_per = round(($today_activity/$today_login)*100);
	$today_activity_per = number_format((float)$today_activity_per, 2, '.', '');
	?>
	<table border="1" width="75%" id="customers">
		<tr><th>Category</th><th>Total Count</th><th>%</th></tr>
		<tr><td>Executives</td><td><?php echo $total_executive; ?></td><td><?php echo $total_executive_per; ?></td></tr>
		<tr><td>Login</td><td><?php echo $today_login; ?></td><td><?php echo $today_login_per; ?></td></tr>
		<tr><td>Activity@10</td><td><?php echo $today_activity; ?></td><td><?php echo $today_activity_per; ?></td></tr>
	</table>
	<?php
		/* Table-3 */
		$agency_master = "select distinct(agency) as agency_code from ul_agent_login where active=1";
		$result = mysqli_query($con, $agency_master);
		$sno = 0;
		?>
		<table border="1" width="75%" id="customers">
			<tr><th>Sno</th><th>Team</th><th>Executives</th><th>Lead</th><th>Loan</th></tr>
		<?php
		while ($row = mysqli_fetch_assoc($result)) {
		$sno = $sno + 1;
		$agency_code = $row['agency_code'];
		$today_exec = getSingleDBVal($con, "select count(*) as target from ul_agent_login where agency = '$agency_code' and attendance_flag=1 and date(attendance_date) >= date(now())");
		$today_lead = getSingleDBVal($con, "select count(*) as target from ul_customer_details where date(soc_prequalify_time)=date(now()) and applicant_type = 'APP' and lead_active_status not in('CANCELLED','DUPLICATE') and date(create_time) >= date(now()) and agent_code in (select username from ul_agent_login where agency ='$agency_code');");
		$today_loan = getSingleDBVal($con, "select count(*) as target from ul_customer_state_status where  cust_id in (select cust_id from ul_customer_details where applicant_type = 'APP' and date(create_time)>=date(now()) and agent_code in (select username from ul_agent_login where agency ='$agency_code')) and esign_status=1");
		?>
			<tr><td><?php echo $sno; ?></td><td><?php echo $row['agency_code']; ?></td><td><?php echo $today_exec; ?></td><td><?php echo $today_lead; ?></td><td><?php echo $today_loan; ?></td></tr>
		<?php
		}
		
	?>
	</table>
	<?php
	/* Table-4 */
    $noofloan1 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) GROUP BY agent_code) temp WHERE temp.cnt=1";
    $loans1 = mysqli_query($con, $noofloan1);
    $noofloan2 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) GROUP BY agent_code) temp WHERE temp.cnt=2";
    $loans2 = mysqli_query($con, $noofloan2);
    $noofloan3 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) GROUP BY agent_code) temp WHERE temp.cnt=3";
    $loans3 = mysqli_query($con, $noofloan3);
    $noofloan4 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) GROUP BY agent_code) temp WHERE temp.cnt=4";
    $loans4 = mysqli_query($con, $noofloan4);
    $noofloan5 = "SELECT COUNT(temp.agent_code) FROM (SELECT agent_code, COUNT(*) AS cnt FROM ul_customer_details c WHERE applicant_type = 'APP' AND DATE(create_time)=date(now()) AND cust_id IN (SELECT cust_id FROM ul_customer_state_status WHERE cust_id=c.cust_id AND esign_status=1) GROUP BY agent_code) temp WHERE temp.cnt=4";
    $loans5 = mysqli_query($con, $noofloan5);

    $today_login = getSingleDBVal($con, "SELECT COUNT(*) AS target FROM ul_agent_login WHERE active=1 AND DATE(attendance_date) >= DATE(NOW());");

    $loan1 = mysqli_fetch_assoc($loans1)['COUNT(temp.agent_code)'];
    $loan2 = mysqli_fetch_assoc($loans2)['COUNT(temp.agent_code)'];
    $loan3 = mysqli_fetch_assoc($loans3)['COUNT(temp.agent_code)'];
    $loan4 = mysqli_fetch_assoc($loans4)['COUNT(temp.agent_code)'];
    $loan5 = mysqli_fetch_assoc($loans5)['COUNT(temp.agent_code)'];

    $total_loans = $loan1 + $loan2 + $loan3 + $loan4 + $loan5;
    $loan0 = $today_login - $total_loans;
?>
	<table border="1" width="55%" height="60" id="customers">
		<tr>
			<th colspan="7" style="text-align: center;">Loans</th>
		</tr>
		<tr>
			<td></td>
			<th>0</th>
			<th>1</th>
			<th>2</th>
			<th>3</th>
			<th>4</th>
			<th>5</th>
		</tr>
		<tr>
			<td>Executive</td>
			<td><?php echo $loan0?></td>
			<td><?php echo $loan1;?></td>
			<td><?php echo $loan2;?></td>
			<td><?php echo $loan3;?></td>
			<td><?php echo $loan4 ;?></td>
			<td><?php echo $loan5;?></td>
		</tr>
	</table>
	
	
	<!--Table-5 -->
	<table border="1" width="55%" height="60" id="customers">
		<tr>
			<th colspan="7" style="text-align: center;">Top Performance</th>
		</tr>
		<tr>
			<td></td>
			<th>Executive</th>
			<th>Lead Count</th>
			<th>Good Lead</th>
			<th>Loans</th>
		</tr>
		<?php
		$s = 0;
		 $agent_top_query = "select agent_code, count(*) as lead from ul_customer_details where cibil_score >650 and applicant_type = 'APP' and lead_active_status not in('CANCELLED','DUPLICATE') and date(create_time)>=date(now()) group by agent_code order by lead desc limit 5";
		$agent_top_result = mysqli_query($con, $agent_top_query );
		
		if ($agent_top_result->num_rows > 0) {
			while ($agent_top_row = $agent_top_result->fetch_assoc()) {
				$s = $s+ 1;
				$agent_name = $agent_top_row["agent_code"];
				$gleads = $agent_top_row["lead"];
				$lead_count = getSingleDBVal($con, "select count(*) as target from ul_customer_details where agent_code='$agent_name' and date(soc_prequalify_time)=date(now()) and applicant_type = 'APP' and lead_active_status not in('CANCELLED','DUPLICATE') and date(create_time) >= DATE(NOW())");
				
				$query = "select count(*) as target from ul_customer_state_status where  cust_id in (select cust_id from ul_customer_details where applicant_type = 'APP' and date(create_time)>=date(now()) and agent_code in (select username from ul_agent_login where username ='$agent_name')) and esign_status=1";
				$today_loans = getSingleDBVal($con, $query);
				$agent_lead= getSingleDBVal($con, "select count(*) as target from ul_customer_details  where applicant_type = 'APP' and date(create_time)>=date(now()) and agent_code='$agent_name'");
		 
			echo "<tr>
				<td>$s</td>
				<td>$agent_name</td>
				<td>$lead_count</td>
				<td>$gleads</td>
				<td>$today_loans</td>
			</tr>";
		   }
		}			
		?>   
	</table>
	<!--Table-6 -->
	<table border="1" width="55%" height="60" id="customers">
		<tr>
			<th colspan="7" style="text-align: center;">Bottom Performance</th>
		</tr>
		<tr>
			<td></td>
			<th>Executive</th>
			<th>Lead Count</th>
			<th>Good Lead</th>
			<th>Loans</th>
		</tr>
	<?php
	$s = 0;
		$agent_top_query = "select agent_code, count(*) as lead from ul_customer_details where cibil_score <= 650 and applicant_type = 'APP' and lead_active_status not in('CANCELLED','DUPLICATE') and date(create_time)>=date(now()) group by agent_code order by lead asc limit 5";
		$agent_top_result = mysqli_query($con, $agent_top_query );
		
		if ($agent_top_result->num_rows > 0) {
			while ($agent_top_row = $agent_top_result->fetch_assoc()) {
				$s = $s+ 1;
				$agent_name = $agent_top_row["agent_code"];
				$gleads = $agent_top_row["lead"];
				$lead_count = getSingleDBVal($con, "select count(*) as target from ul_customer_details where agent_code='$agent_name' and date(soc_prequalify_time)=date(now()) and applicant_type = 'APP' and lead_active_status not in('CANCELLED','DUPLICATE') and date(create_time) >= DATE(NOW())");
				
				$query = "select count(*) as target from ul_customer_state_status where  cust_id in (select cust_id from ul_customer_details where applicant_type = 'APP' and date(create_time)>=date(now()) and agent_code in (select username from ul_agent_login where username ='$agent_name')) and esign_status=1";
				$today_loans = getSingleDBVal($con, $query);
				$agent_lead= getSingleDBVal($con, "select count(*) as target from ul_customer_details  where applicant_type = 'APP' and date(create_time)>=date(now()) and agent_code='$agent_name'");
		 
			echo "<tr>
				<td>$s</td>
				<td>$agent_name</td>
				<td>$lead_count</td>
				<td>$gleads</td>
				<td>$today_loans</td>
				</tr>";
		   }
		}					
	?>  
	</table>

	
	</center>
	</div>
  </body>
</html>
