// In the following example, markers appear when the user clicks on the map.
// Each marker is labeled with a single alphabetical character.
const labels = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
let labelIndex = 0;
let MarkerArr = [];
let pathLines = [];

// map initialisation
async function initMap() {
  const { Map } = await google.maps.importLibrary("maps");
  const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");

  const chennai = { lat: 13.067439, lng: 80.237617 };
  const map = new Map(document.getElementById("map"), {
    zoom: 11,
    center: chennai,
    mapId: "4504f8b37365c3d0",
    heading:90,
    tilt:45
  });

  const geocoder = new google.maps.Geocoder();
  //function call initial
  getAgentData(geocoder, map);
  // call at a interval
  setInterval(  function() {
    console.log("errasing markers!!!!");
    erraseAgentMarkersAndLines();
    getAgentData(geocoder, map);
  }, 60000);
}

//call the api
function getAgentData(geocoder, map) {
  let post = `{
    "appName":"in.fl.uplift.agent",
    "customerId":"100000002",
    "device_id":"-b040-4513-9011-439a24476860",
    "installId":"0",
    "random":"1682687048246",
    "requestCreatedAt":"2023-04-28, 18:34:26",
    "version":"40.00"
  }`;

  fetch("https://app.friendloan.in/FLUPLIFT/getAgentTaskTrackingDetails", {
    method: 'post',
    body: post,
    headers: {
      'Content-Type': 'application/json',
    }
    }).then((response) => {
        return response.json();
    }).then((res) => {
      // console.log(res);
      plotAllocatedTasksAndAgentsMarkers(geocoder, map, res.allocatedTaskDetails);
      plotUnAllocatedTasksMarkers(geocoder, map, res.unallocatedTasks);
      plotAvailableAgentsMarkers(geocoder, map, res.availableAgents);
    }).catch((error) => {
      alert("Error in fetching agent Data!!!");
      console.log(error);
    })

}

// erase the markers
function erraseAgentMarkersAndLines(){
  // for removing the markers
  let arrLen = MarkerArr.length;
  for (let i = 0; i < arrLen; i++) {
    MarkerArr[i].map = null;
  }
  // for removing the lines
  let pathLineLength = pathLines.length;
  for (let i = 0; i < pathLineLength; i++) {
    pathLines[i].setMap(null);
  }

  MarkerArr = [];
  pathLines = [];
}

// plot the Lines for between allocated Tasks and Agents
async function plotAllocatedTasksAndAgentsMarkers(geocoder, map, allocatedTaskDetails){
  if(allocatedTaskDetails===null || allocatedTaskDetails.length===0){
    console.log("No allocated TaskDetails found");
    return;
  }
  for (let i = 0; i < allocatedTaskDetails.length; i++) {
    //console.log(JSON.stringify(allocatedTaskDetails[i]));
    const agentLoc = allocatedTaskDetails[i].agentLoction;
    const taskLoc = allocatedTaskDetails[i].taskLoction;
    
    if(agentLoc != null && agentLoc !== "" && taskLoc != null && taskLoc !== "" ){
        const agentLatLngStr = agentLoc.split(",");
        const taskLatLngStr = taskLoc.split(",");

        const agentLocation = {
          lat: parseFloat(agentLatLngStr[0]),
          lng: parseFloat(agentLatLngStr[1])
        };
        const taskLocation = {
          lat: parseFloat(taskLatLngStr[0]),
          lng: parseFloat(taskLatLngStr[1])
        };

        const path = [agentLocation, taskLocation];

        let line= new google.maps.Polyline({
          path: path,
          geodesic: true,
          strokeColor: '#FF0000',
          strokeOpacity: 1.0,
          strokeWeight: 3
        });
        pathLines.push(line);
        line.setMap(map);
        await geoMapCordinatesAllocatedTasks(geocoder,map, allocatedTaskDetails[i]);
    }
  }
}

// plot the geomarkers for Allocated Tasks and Agents
async function geoMapCordinatesAllocatedTasks(geocoder, map, taskDetails) {
  const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");
  //alert(input);
  const agentLoc = taskDetails.agentLoction;
  const taskLoc = taskDetails.taskLoction;

  if (agentLoc != null && agentLoc !== "" && taskLoc != null && taskLoc !== "" ) {
      const agentLatLngStr = agentLoc.split(",");
      const taskLatLngStr = taskLoc.split(",");
      const agentLocation = {
        lat: parseFloat(agentLatLngStr[0]),
        lng: parseFloat(agentLatLngStr[1]),
      };
      const taskLocation = {
        lat: parseFloat(taskLatLngStr[0]),
        lng: parseFloat(taskLatLngStr[1]),
      };
      
      let agentShape= taskDetails.agentShape;
      let agentColor= taskDetails.agentColor;

      let taskShape= taskDetails.taskShape;
      let taskColor= taskDetails.taskColor;

      const agentContentValue = document.createElement("div");
      const taskContentValue = document.createElement("div");
      
      agentContentValue.classList.add("agent"); 
      agentContentValue.classList.add(agentShape);
      agentContentValue.classList.add("collapsed");

      taskContentValue.classList.add("agent");
      taskContentValue.classList.add(taskShape);
      taskContentValue.classList.add("collapsed");

      agentContentValue.innerHTML = `
            <div class="icon">
                <img src="${getShapeSVG(agentShape, agentColor)}" alt="${agentShape}">
            </div>
            <div class="name">
              ${taskDetails.name} 
            </div>`;

      taskContentValue.innerHTML = `
            <div class="icon">
                <img src="${getShapeSVG(taskShape, taskColor)}" alt="${taskShape}">
            </div>
            <div class="id">
              ${taskDetails.custId} 
            </div>`;
          
      let AgentTitleVal = taskDetails.dispAgentText;
      let TaskTitleVal = taskDetails.dispTaskText;

      const agentMarker = new AdvancedMarkerElement({
        map,
        position: agentLocation,
        content: agentContentValue,
        title: AgentTitleVal,
      });

      const taskMarker = new AdvancedMarkerElement({
        map,
        position: taskLocation,
        content: taskContentValue,
        title: TaskTitleVal,
      });

      agentMarker.addListener("click", () => {
        toggleHighlight(agentMarker);
      });
      taskMarker.addListener("click", () => {
        toggleHighlight(taskMarker);
      });

      MarkerArr.push(agentMarker);
      MarkerArr.push(taskMarker);
    } else {
      window.alert("No results found");
    }
}

// plot the geomarkers for UnAllocated Tasks
async function plotUnAllocatedTasksMarkers(geocoder, map, unallocatedTasks) {
  const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");
  if(unallocatedTasks===null || unallocatedTasks.length===0){
    console.log("No unallocated Tasks found");
    return;
  }
  for (let i = 0; i < unallocatedTasks.length; i++) {
    const taskDetails= unallocatedTasks[i];
    const taskLoc = taskDetails.location;
    if (taskLoc != null && taskLoc !== "" ) {
      const taskLatLngStr = taskLoc.split(",");
      const taskLocation = {
        lat: parseFloat(taskLatLngStr[0]),
        lng: parseFloat(taskLatLngStr[1]),
      };
      let taskShape= taskDetails.shape;
      let taskColor= taskDetails.color;

      const taskContentValue = document.createElement("div");

      taskContentValue.classList.add("agent");
      taskContentValue.classList.add(taskShape);
      taskContentValue.classList.add("collapsed");

      taskContentValue.innerHTML = `
            <div class="icon">
                <img src="${getShapeSVG(taskShape, taskColor)}" alt="${taskShape}">
            </div>
            <div class="id">
              ${taskDetails.custId} 
            </div>`;
          
      let TaskTitleVal = taskDetails.dispText;

      const taskMarker = new AdvancedMarkerElement({
        map,
        position: taskLocation,
        content: taskContentValue,
        title: TaskTitleVal,
      });

      taskMarker.addListener("click", () => {
        toggleHighlight(taskMarker);
      });

      MarkerArr.push(taskMarker);
    }
  } 
}

// plot the geomarkers for availableAgents
async function plotAvailableAgentsMarkers(geocoder, map, availableAgents) {
  if(availableAgents===null || availableAgents.length===0){
    console.log("No available Agents found");
    return;
  }
  const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");
  for (let i = 0; i < availableAgents.length; i++) {
    const availableAgent = availableAgents[i];
    const agentLoc = availableAgent.location;

    if (agentLoc != null && agentLoc !== "") {
      const agentLatLngStr = agentLoc.split(",");
      const agentLocation = {
        lat: parseFloat(agentLatLngStr[0]),
        lng: parseFloat(agentLatLngStr[1])
      };
      
      let agentShape= availableAgent.shape;
      let agentColor= availableAgent.color;

      const agentContentValue = document.createElement("div");
      
      agentContentValue.classList.add("agent");
      agentContentValue.classList.add(agentShape);
      agentContentValue.classList.add("collapsed");

      agentContentValue.innerHTML = `
            <div class="icon">
                <img src="${getShapeSVG(agentShape, agentColor)}" alt="${agentShape}">
            </div>
            <div class="name">
              ${availableAgent.name} 
            </div>`;

      let AgentTitleVal = availableAgent.dispText;

      const agentMarker = new AdvancedMarkerElement({
        map,
        position: agentLocation,
        content: agentContentValue,
        title: AgentTitleVal,
      });

      agentMarker.addListener("click", () => {
        toggleHighlight(agentMarker);
      });

      MarkerArr.push(agentMarker);
    }
  }
}

function toggleHighlight(markerView) {
  if (markerView.content.classList.contains("collapsed")) {
    markerView.content.classList.remove("collapsed");
    markerView.zIndex = 1;
  } else {
    markerView.content.classList.add("collapsed");
    markerView.zIndex = null;
  }
}


function getShapeSVG(shape, color) {
  const shapes = {
    CIRCLE: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><circle cx="12" cy="12" r="10" fill="${color}" /></svg>`,
    TRIANGLE: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><polygon points="12,2 2,22 22,22" fill="${color}" /></svg>`,
    SQUARE: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><rect x="4" y="4" width="16" height="16" fill="${color}" /></svg>`,
    STAR: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><polygon points="12,2 15,9 22,9 17,14 18,22 12,18 6,22 7,14 2,9 9,9" fill="${color}" /></svg>`
  };

  return `data:image/svg+xml;base64,${btoa(shapes[shape])}`;
}

window.initMap = initMap;


